import React, { useState, useEffect, useRef } from "react";
import {
  Menu,
  X,
  Play,
  Pause,
  ArrowRight,
  Mic,
  AudioWaveform as WaveformIcon,
  Sparkles,
  Send,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Zap,
  Globe2,
} from "lucide-react";

/**
 * Scroll Reveal Component: FadeInUp
 * Slides elements up from translate-y-10 and opacity-0 to opacity-100 over 1000ms
 */
function FadeInUp({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const [isVisible, setIsVisible] = useState(false);
  const domRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          if (domRef.current) {
            observer.unobserve(domRef.current);
          }
        }
      },
      {
        threshold: 0.12,
        rootMargin: "0px 0px -40px 0px",
      }
    );

    const currentEl = domRef.current;
    if (currentEl) {
      observer.observe(currentEl);
    }

    return () => {
      if (currentEl) observer.unobserve(currentEl);
    };
  }, []);

  return (
    <div
      ref={domRef}
      style={{
        transitionDuration: "1000ms",
        transitionDelay: `${delay}ms`,
      }}
      className={`transform transition-all ease-out ${
        isVisible
          ? "opacity-100 translate-y-0"
          : "opacity-0 translate-y-10 pointer-events-none"
      } ${className}`}
    >
      {children}
    </div>
  );
}

/**
 * Modern stroke-based geometric SVG logo for "Plety"
 * Mimicking the sleek style of "Untitled UI" logos
 */
function PletyLogo({ className = "w-7 h-7" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="1.5" strokeOpacity="0.3" />
      <path
        d="M10 22V10C10 10 14 7 18 10C22 13 22 19 18 22C14 25 10 22 10 22Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="15.5" cy="15.5" r="2.5" fill="currentColor" />
    </svg>
  );
}

/**
 * Stroke-based SVG Dummy Brand Logos for the marquee
 */
function SpringfieldLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="text-base font-semibold tracking-wider text-gray-300">Springfield</span>
    </div>
  );
}

function OrbitcLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
        <circle cx="12" cy="12" r="9" />
        <ellipse cx="12" cy="12" rx="9" ry="3.5" transform="rotate(-30 12 12)" />
      </svg>
      <span className="text-base font-semibold tracking-wider text-gray-300">Orbitc</span>
    </div>
  );
}

function CloudLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
        <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="text-base font-semibold tracking-wider text-gray-300">Cloud</span>
    </div>
  );
}

function AmsterLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
        <polygon points="12 2 2 22 22 22" strokeLinecap="round" strokeLinejoin="round" />
        <line x1="7" y1="15" x2="17" y2="15" strokeLinecap="round" />
      </svg>
      <span className="text-base font-semibold tracking-wider text-gray-300">Amster</span>
    </div>
  );
}

function NexusLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
        <rect x="3" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="14" width="7" height="7" rx="1.5" />
        <rect x="3" y="14" width="7" height="7" rx="1.5" />
      </svg>
      <span className="text-base font-semibold tracking-wider text-gray-300">Nexus</span>
    </div>
  );
}

export default function App() {
  // Navigation scroll state
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Interactive AI Chat State
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "ai"; text: string }>>([
    {
      role: "user",
      text: "Can you analyze our Q3 retention cohort and summarize risk factors?",
    },
    {
      role: "ai",
      text: "Cohort analysis complete: Retention in enterprise tiers rose by 18%, while mid-market drop-off is linked to API token rate limits. I have prepared an automatic scaling rule proposal.",
    },
  ]);
  const [isSending, setIsSending] = useState(false);

  // Interactive Transcription Player State
  const [isPlayingAudio, setIsPlayingAudio] = useState(true);
  const [audioProgress, setAudioProgress] = useState(38);

  // Modal State for CTA clicks
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  // Handle scroll listener for navigation bar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Audio simulation timer
  useEffect(() => {
    if (!isPlayingAudio) return;
    const interval = setInterval(() => {
      setAudioProgress((prev) => (prev >= 100 ? 0 : prev + 1));
    }, 300);
    return () => clearInterval(interval);
  }, [isPlayingAudio]);

  const handleNavClick = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || isSending) return;

    const userText = chatInput.trim();
    setChatInput("");
    setChatMessages((prev) => [...prev, { role: "user", text: userText }]);
    setIsSending(true);

    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          role: "ai",
          text: `Processed "${userText.slice(0, 32)}...": Applied real-time context analysis with 99.4% confidence score.`,
        },
      ]);
      setIsSending(false);
    }, 800);
  };

  const handleOpenGetStarted = (source: string) => {
    setModalMessage(`Thank you for your interest in Plety API 2.0 (${source}). Enterprise onboarding is ready.`);
    setIsModalOpen(true);
  };

  const faqItems = [
    {
      question: "Is my data safe and encrypted?",
      answer:
        "Yes. All audio streams, conversational queries, and model embeddings are encrypted both in transit using TLS 1.3 and at rest with military-grade AES-256 encryption. We strictly enforce zero-data retention policies so your proprietary operational data is never used to train foundational AI models.",
    },
    {
      question: "How quickly can we integrate Plety into our stack?",
      answer:
        "Integration takes less than 15 minutes. With our unified REST API, WebSocket streaming interfaces, and native SDKs for TypeScript, Python, Go, and Rust, you can embed conversational intelligence directly into your existing architecture with just a few lines of code.",
    },
    {
      question: "What models power Plety's intelligence layer?",
      answer:
        "Plety operates a high-throughput hybrid architecture. We combine frontier multimodal reasoning engines with specialized low-latency neural acoustic networks, delivering sub-50ms conversational response times with deep contextual comprehension.",
    },
    {
      question: "Can Plety transcribe in multiple languages simultaneously?",
      answer:
        "Yes. Plety natively identifies, transcribes, and translates across 95+ languages. Our engine features automatic acoustic code-switching to handle multi-speaker, multilingual conversations seamlessly without needing manual language tags.",
    },
    {
      question: "What kind of enterprise support and SLA do you provide?",
      answer:
        "Enterprise tiers receive a guaranteed 99.99% uptime SLA, dedicated technical account managers, private VPC or on-premise container deployment options, custom fine-tuning pipelines, and 24/7 priority incident response.",
    },
  ];

  const brandLogos = [
    { id: 1, component: <SpringfieldLogo /> },
    { id: 2, component: <OrbitcLogo /> },
    { id: 3, component: <CloudLogo /> },
    { id: 4, component: <AmsterLogo /> },
    { id: 5, component: <NexusLogo /> },
  ];

  // Duplicate 4 times to guarantee seamless infinite loop
  const marqueeItems = [...brandLogos, ...brandLogos, ...brandLogos, ...brandLogos];

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-white/20 selection:text-white relative overflow-x-hidden">
      {/* 1. Navigation Bar (Sticky & Responsive) */}
      <nav
        id="navbar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-black/80 backdrop-blur-md border-b border-white/5 py-4 shadow-lg shadow-black/40"
            : "bg-transparent py-6"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo on Left */}
          <button
            id="nav-brand-logo"
            onClick={() => handleNavClick("about")}
            className="flex items-center gap-2.5 group cursor-pointer focus:outline-none"
          >
            <div className="text-white group-hover:scale-105 transition-transform duration-200">
              <PletyLogo className="w-8 h-8" />
            </div>
            <span className="text-xl font-bold tracking-tight text-white">Plety</span>
          </button>

          {/* Links in Center (Desktop) */}
          <div className="hidden md:flex items-center gap-8">
            <button
              id="nav-link-about"
              onClick={() => handleNavClick("about")}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              id="nav-link-features"
              onClick={() => handleNavClick("features")}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              id="nav-link-faq"
              onClick={() => handleNavClick("faq")}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              FAQ
            </button>
            <button
              id="nav-link-contact"
              onClick={() => handleNavClick("contact")}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              Contact
            </button>
          </div>

          {/* Right Action Button (Desktop) */}
          <div className="hidden md:flex items-center">
            <button
              id="nav-get-started-btn"
              onClick={() => handleOpenGetStarted("Nav")}
              className="bg-[#1F1F22] hover:bg-[#2A2A2D] text-white text-sm font-medium px-5 py-2.5 rounded-full border border-white/5 hover:border-white/15 transition-all shadow-sm cursor-pointer active:scale-95"
            >
              Get started
            </button>
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="md:hidden flex items-center">
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-gray-300 hover:text-white focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div
            id="mobile-nav-dropdown"
            className="md:hidden bg-black/95 backdrop-blur-xl border-b border-white/10 px-6 py-6 transition-all duration-300 space-y-4 animate-in fade-in slide-in-from-top-4"
          >
            <div className="flex flex-col gap-4">
              <button
                id="mobile-link-about"
                onClick={() => handleNavClick("about")}
                className="text-left text-base font-medium text-gray-300 hover:text-white py-2 border-b border-white/5"
              >
                About
              </button>
              <button
                id="mobile-link-features"
                onClick={() => handleNavClick("features")}
                className="text-left text-base font-medium text-gray-300 hover:text-white py-2 border-b border-white/5"
              >
                Features
              </button>
              <button
                id="mobile-link-faq"
                onClick={() => handleNavClick("faq")}
                className="text-left text-base font-medium text-gray-300 hover:text-white py-2 border-b border-white/5"
              >
                FAQ
              </button>
              <button
                id="mobile-link-contact"
                onClick={() => handleNavClick("contact")}
                className="text-left text-base font-medium text-gray-300 hover:text-white py-2 border-b border-white/5"
              >
                Contact
              </button>
              <div className="pt-2">
                <button
                  id="mobile-get-started-btn"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    handleOpenGetStarted("Mobile Nav");
                  }}
                  className="w-full bg-[#1F1F22] hover:bg-[#2A2A2D] text-white text-sm font-medium px-5 py-3 rounded-full border border-white/10 text-center transition-all"
                >
                  Get started
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* 2. Hero Section (id="about") */}
      <section
        id="about"
        className="min-h-screen flex flex-col items-center justify-center pt-32 pb-20 relative z-0 overflow-hidden"
      >
        {/* Background Video */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover -z-10 opacity-90 min-w-full min-h-full"
          src="https://cdn.sceneai.art/Hero%20Section%20Video/50b4f304-cdca-4e12-8735-580d225834be.mp4"
        />

        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black -z-10 pointer-events-none" />

        <div className="max-w-5xl mx-auto px-6 flex flex-col items-center text-center">
          {/* Top Badge */}
          <FadeInUp delay={100}>
            <button
              id="hero-top-badge"
              onClick={() => handleOpenGetStarted("Announcing API 2.0")}
              className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-gray-300 mb-8 backdrop-blur-sm hover:border-white/20 hover:bg-white/10 transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
            >
              <span>✨</span>
              <span>Announcing API 2.0</span>
              <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
            </button>
          </FadeInUp>

          {/* Headline */}
          <FadeInUp delay={250}>
            <h1
              id="hero-headline"
              className="text-5xl md:text-7xl font-medium tracking-tight mb-6 text-center text-white leading-[1.1]"
            >
              The intelligence layer <br className="hidden sm:inline" />
              for clear <span className="font-serif italic font-normal text-white">decisions.</span>
            </h1>
          </FadeInUp>

          {/* Sub-text */}
          <FadeInUp delay={400}>
            <p
              id="hero-subtext"
              className="text-[16px] text-gray-400 max-w-2xl text-center mb-10 leading-relaxed font-normal"
            >
              Our platform integrates seamlessly into your stack to deliver real-time understanding, not just predictions.
            </p>
          </FadeInUp>

          {/* Buttons: Flex row */}
          <FadeInUp delay={550}>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <button
                id="hero-primary-btn"
                onClick={() => handleOpenGetStarted("Hero Primary")}
                className="w-full sm:w-auto bg-white hover:bg-neutral-200 text-black font-medium px-7 py-3.5 rounded-full text-sm transition-all duration-200 shadow-md hover:shadow-white/10 active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Get started</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                id="hero-secondary-btn"
                onClick={() => handleNavClick("features")}
                className="w-full sm:w-auto bg-[#1F1F22] hover:bg-[#2A2A2D] text-white font-medium px-7 py-3.5 rounded-full text-sm border border-white/5 hover:border-white/15 transition-all duration-200 active:scale-95 cursor-pointer flex items-center justify-center"
              >
                Learn more
              </button>
            </div>
          </FadeInUp>

          {/* Marquee (Trusted by industry leaders) */}
          <div className="w-full mt-24">
            <FadeInUp delay={700}>
              <p
                id="marquee-title"
                className="text-sm text-gray-500 font-medium mb-8 text-center uppercase tracking-wider"
              >
                Trusted by industry leaders
              </p>

              {/* Flawless infinite loop with overflow-hidden and mask-image */}
              <div className="overflow-hidden mask-marquee w-full py-4 relative">
                <div className="flex w-max animate-marquee items-center">
                  {marqueeItems.map((logo, index) => (
                    <div
                      key={`marquee-${logo.id}-${index}`}
                      className="flex-shrink-0 px-8 opacity-75 hover:opacity-100 transition-opacity duration-200 cursor-default"
                    >
                      {logo.component}
                    </div>
                  ))}
                </div>
              </div>
            </FadeInUp>
          </div>
        </div>
      </section>

      {/* 3. Feature 1: AI Chat (id="features") */}
      <section id="features" className="py-24 px-6 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Text */}
          <FadeInUp delay={150}>
            <div className="flex flex-col">
              <span
                id="feature1-badge"
                className="text-amber-300 bg-amber-400/10 border border-amber-400/20 px-3 py-1 rounded-full text-xs font-medium inline-flex items-center gap-1.5 w-fit mb-4"
              >
                <span>✨</span>
                <span>AI chat</span>
              </span>

              <h2
                id="feature1-headline"
                className="text-4xl md:text-5xl font-semibold text-white tracking-tight mb-6 leading-tight"
              >
                Where speed meets intelligent conversation.
              </h2>

              <p
                id="feature1-subtext"
                className="text-gray-400 text-base leading-relaxed mb-8"
              >
                A conversational AI assistant that understands your questions, provides intelligent answers, and helps you get things done fast from casual chats to complex tasks.
              </p>

              <div>
                <button
                  id="feature1-btn"
                  onClick={() => handleOpenGetStarted("Feature AI Chat")}
                  className="bg-white hover:bg-neutral-200 text-black font-medium px-6 py-3 rounded-full text-sm inline-flex items-center gap-2 transition-all active:scale-95 cursor-pointer shadow-md"
                >
                  <span>Get started</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </FadeInUp>

          {/* Right Mockup */}
          <FadeInUp delay={300}>
            <div
              id="feature1-mockup-wrapper"
              className="rounded-3xl overflow-hidden p-6 sm:p-8 border border-white/10 relative min-h-[460px] flex items-center justify-center shadow-2xl bg-neutral-950"
            >
              {/* Background Video */}
              <video
                autoPlay
                loop
                muted
                playsInline
                className="absolute inset-0 object-cover w-full h-full"
                src="https://cdn.sceneai.art/Hero%20Section%20Video/1bcc8fa3-37f6-4c53-8591-0347e4c7f8ac.mp4"
              />
              <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" />

              {/* Floating UI Card */}
              <div
                id="feature1-card"
                className="bg-[#1C1C1E]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-2xl w-full max-w-md relative z-10 space-y-4"
              >
                {/* Top Chips */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
                  <span className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/15 text-gray-200 font-medium border border-white/10 transition-colors whitespace-nowrap flex items-center gap-1 cursor-pointer">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    Create image
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/15 text-gray-200 font-medium border border-white/10 transition-colors whitespace-nowrap cursor-pointer">
                    Summarize
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/15 text-gray-200 font-medium border border-white/10 transition-colors whitespace-nowrap cursor-pointer">
                    Code review
                  </span>
                </div>

                {/* Messages Body */}
                <div className="space-y-3 max-h-[190px] overflow-y-auto pr-1 text-xs sm:text-sm">
                  {chatMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${
                        msg.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl p-3 leading-relaxed ${
                          msg.role === "user"
                            ? "bg-white/15 text-white border border-white/10"
                            : "bg-[#27272A]/80 text-gray-200 border border-white/5"
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                  ))}
                  {isSending && (
                    <div className="flex justify-start">
                      <div className="bg-[#27272A]/80 text-gray-400 rounded-2xl p-3 text-xs flex items-center gap-2">
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce" />
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:0.2s]" />
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-bounce [animation-delay:0.4s]" />
                        <span>Plety AI is generating analysis...</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Input Area */}
                <form
                  onSubmit={handleSendChat}
                  className="flex items-center gap-2 bg-black/50 border border-white/10 rounded-xl px-3 py-2"
                >
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Ask anything..."
                    className="bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none flex-1 min-w-0"
                  />
                  <div className="flex items-center gap-1.5 text-gray-400">
                    <button
                      type="button"
                      onClick={() => setChatInput("Summarize latency metrics across clusters")}
                      className="p-1.5 hover:text-white transition-colors rounded-lg hover:bg-white/5"
                      title="Voice Input"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      className="p-1.5 hover:text-white transition-colors rounded-lg hover:bg-white/5"
                      title="Audio Stream"
                    >
                      <WaveformIcon className="w-4 h-4" />
                    </button>
                    <button
                      type="submit"
                      disabled={!chatInput.trim() || isSending}
                      className="p-1.5 bg-white text-black rounded-lg hover:bg-gray-200 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                      title="Send message"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </FadeInUp>
        </div>
      </section>

      {/* 4. Feature 2: AI Transcription */}
      <section className="py-24 px-6 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Mockup */}
          <div className="order-2 lg:order-1">
            <FadeInUp delay={200}>
              <div
                id="feature2-mockup-wrapper"
                className="rounded-3xl overflow-hidden p-6 sm:p-8 border border-white/10 relative min-h-[460px] flex items-center justify-center shadow-2xl bg-neutral-950"
              >
                {/* Background Video */}
                <video
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute inset-0 object-cover w-full h-full"
                  src="https://cdn.sceneai.art/Hero%20Section%20Video/736fd4a0-70ac-4f44-9633-55769ead6aca.mp4"
                />
                <div className="absolute inset-0 bg-black/25 backdrop-blur-[2px]" />

                {/* Floating UI Card */}
                <div
                  id="feature2-card"
                  className="bg-[#1C1C1E]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-2xl w-full max-w-md relative z-10 space-y-4"
                >
                  {/* Top Audio Player Header */}
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                        className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:bg-gray-200 transition-all shadow-md active:scale-95 cursor-pointer"
                        title={isPlayingAudio ? "Pause" : "Play"}
                      >
                        {isPlayingAudio ? (
                          <Pause className="w-4 h-4 fill-black" />
                        ) : (
                          <Play className="w-4 h-4 fill-black ml-0.5" />
                        )}
                      </button>
                      <div>
                        <div className="text-sm font-semibold text-white">11:06 AM – Chris</div>
                        <div className="text-xs text-gray-400">Quarterly Strategy Briefing • Voice memo</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full border border-emerald-400/20">
                      Live 99.8% Acc
                    </span>
                  </div>

                  {/* Waveform Visualization */}
                  <div className="space-y-1.5">
                    <div className="flex items-end justify-between gap-1 h-12 py-1 px-1 bg-black/40 rounded-xl border border-white/5">
                      {[35, 60, 45, 80, 65, 95, 40, 75, 90, 50, 70, 85, 30, 95, 60, 40, 80, 55, 75, 45, 90, 65, 35, 70, 85, 40, 60, 50].map(
                        (height, index) => {
                          const isBarActive = (index / 28) * 100 <= audioProgress;
                          return (
                            <div
                              key={index}
                              style={{
                                height: `${isPlayingAudio ? Math.max(15, (height * (0.8 + Math.sin(index + audioProgress * 0.1) * 0.25))) : height * 0.6}%`,
                              }}
                              className={`w-full rounded-full transition-all duration-150 ${
                                isBarActive
                                  ? "bg-emerald-400 shadow-sm shadow-emerald-400/50"
                                  : "bg-white/20"
                              }`}
                            />
                          );
                        }
                      )}
                    </div>
                    <div className="flex justify-between text-[11px] font-mono text-gray-500 px-1">
                      <span>01:14</span>
                      <span>03:42</span>
                    </div>
                  </div>

                  {/* Transcription Output Card */}
                  <div className="bg-black/50 border border-white/5 rounded-xl p-3 space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Transcribed in 12ms</span>
                    </div>
                    <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                      &ldquo;We have finalized the Q3 intelligence roadmap. The primary latency optimization achieved a 42% reduction across core inference pipelines, ensuring sub-50ms conversational streaming for enterprise clients.&rdquo;
                    </p>
                  </div>
                </div>
              </div>
            </FadeInUp>
          </div>

          {/* Right Text */}
          <div className="order-1 lg:order-2">
            <FadeInUp delay={350}>
              <div className="flex flex-col">
                <span
                  id="feature2-badge"
                  className="text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-3 py-1 rounded-full text-xs font-medium inline-flex items-center gap-1.5 w-fit mb-4"
                >
                  <span>✨</span>
                  <span>AI transcription</span>
                </span>

                <h2
                  id="feature2-headline"
                  className="text-4xl md:text-5xl font-semibold text-white tracking-tight mb-6 leading-tight"
                >
                  Turn speech into text with speed and precision.
                </h2>

                <p
                  id="feature2-subtext"
                  className="text-gray-400 text-base leading-relaxed mb-8"
                >
                  Automatically convert speech into accurate, editable text in real time. Perfect for meetings, interviews, voice notes, and more, powered by advanced speech recognition technology.
                </p>

                <div>
                  <button
                    id="feature2-btn"
                    onClick={() => handleOpenGetStarted("Feature Transcription")}
                    className="bg-white hover:bg-neutral-200 text-black font-medium px-6 py-3 rounded-full text-sm inline-flex items-center gap-2 transition-all active:scale-95 cursor-pointer shadow-md"
                  >
                    <span>Get started</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </FadeInUp>
          </div>
        </div>
      </section>

      {/* 5. FAQ Section (id="faq") */}
      <section id="faq" className="py-32 px-6 max-w-3xl mx-auto">
        <FadeInUp delay={100}>
          <h2
            id="faq-headline"
            className="text-4xl md:text-5xl font-semibold mb-12 text-white text-center tracking-tight"
          >
            We&apos;ve got answers
          </h2>
        </FadeInUp>

        {/* Main Wrapper matching specification: completely transparent with border */}
        <FadeInUp delay={250}>
          <div
            id="faq-accordion-container"
            className="border border-white/10 rounded-xl bg-transparent overflow-hidden shadow-2xl"
          >
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              const isLast = index === faqItems.length - 1;

              return (
                <div
                  key={index}
                  id={`faq-item-${index}`}
                  className={`${!isLast ? "border-b border-white/10" : ""}`}
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                    className="w-full py-6 px-6 flex items-center justify-between text-left hover:bg-white/[0.02] transition-colors focus:outline-none cursor-pointer group"
                    aria-expanded={isOpen}
                  >
                    <span className="text-base text-white font-medium pr-4 group-hover:text-gray-200 transition-colors">
                      {item.question}
                    </span>
                    {/* Plus (+) that rotates perfectly into an (x) */}
                    <span
                      className={`text-gray-400 group-hover:text-white transition-transform duration-300 flex-shrink-0 text-xl font-light leading-none transform ${
                        isOpen ? "rotate-45" : "rotate-0"
                      }`}
                    >
                      +
                    </span>
                  </button>

                  {/* Answer body using CSS grid trick (grid-template-rows: 0fr to 1fr) */}
                  <div
                    className={`grid transition-[grid-template-rows] duration-300 ease-out ${
                      isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="text-gray-400 text-sm pb-6 px-6 leading-relaxed">
                        {item.answer}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </FadeInUp>
      </section>

      {/* 6. Footer Section (id="contact") */}
      <footer id="contact" className="relative z-0 pt-32 pb-10 px-6 border-t border-white/5 overflow-hidden">
        {/* Background Video with strong gradient overlay */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 object-cover w-full h-full opacity-40 -z-10"
          src="https://cdn.sceneai.art/Hero%20Section%20Video/50b4f304-cdca-4e12-8735-580d225834be.mp4"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-black/60 to-black -z-10 pointer-events-none" />

        <div className="max-w-7xl mx-auto">
          {/* Top CTA */}
          <div className="flex flex-col items-center text-center mb-32">
            <FadeInUp delay={100}>
              <h2
                id="footer-cta-headline"
                className="text-4xl md:text-6xl font-medium tracking-tight mb-8 text-center text-white"
              >
                Ready to automate{" "}
                <span className="font-serif italic font-normal text-white">everything?</span>
              </h2>
            </FadeInUp>

            <FadeInUp delay={250}>
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <button
                  id="footer-cta-primary-btn"
                  onClick={() => handleOpenGetStarted("Footer CTA")}
                  className="w-full sm:w-auto bg-white hover:bg-neutral-200 text-black font-medium px-7 py-3.5 rounded-full text-sm transition-all duration-200 shadow-md active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Get started</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  id="footer-cta-secondary-btn"
                  onClick={() => handleNavClick("about")}
                  className="w-full sm:w-auto bg-[#1F1F22] hover:bg-[#2A2A2D] text-white font-medium px-7 py-3.5 rounded-full text-sm border border-white/5 hover:border-white/15 transition-all duration-200 active:scale-95 cursor-pointer flex items-center justify-center"
                >
                  Learn more
                </button>
              </div>
            </FadeInUp>
          </div>

          {/* Link Grid */}
          <FadeInUp delay={300}>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-8 mb-24">
              {/* Col 1: Plety Logo + Title + Subtext */}
              <div className="space-y-3">
                <div className="flex items-center gap-2.5">
                  <PletyLogo className="w-6 h-6 text-white" />
                  <span className="text-xl font-bold tracking-tight text-white">Plety</span>
                </div>
                <p className="text-sm text-gray-400 leading-relaxed max-w-xs">
                  Speed, scale, and smarts — deployed.
                </p>
              </div>

              {/* Col 2 (Product) */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-white tracking-wider">Product</h4>
                <ul className="space-y-2.5">
                  <li>
                    <button
                      onClick={() => handleNavClick("about")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      About
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => handleOpenGetStarted("Pricing")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Pricing
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => handleOpenGetStarted("Changelog")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Changelog
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => handleNavClick("contact")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Contact
                    </button>
                  </li>
                </ul>
              </div>

              {/* Col 3 (Legal) */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-white tracking-wider">Legal</h4>
                <ul className="space-y-2.5">
                  <li>
                    <button
                      onClick={() => handleOpenGetStarted("Terms")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Terms of service
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => handleOpenGetStarted("Privacy")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Privacy policy
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => handleOpenGetStarted("404")}
                      className="text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
                    >
                      404
                    </button>
                  </li>
                </ul>
              </div>

              {/* Col 4 (Connect) */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-white tracking-wider">Connect</h4>
                <ul className="space-y-2.5">
                  <li>
                    <a
                      href="https://instagram.com"
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      Instagram
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://youtube.com"
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      YouTube
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://linkedin.com"
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      LinkedIn
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://twitter.com"
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      Twitter / X
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </FadeInUp>

          {/* Bottom Bar matching exact layout specification */}
          <div
            id="footer-bottom-bar"
            className="flex flex-col md:flex-row justify-center items-center gap-2 md:gap-4 text-xs text-gray-500 border-t border-white/5 pt-8 text-center"
          >
            <span>&copy; 2026 Plety. All rights reserved</span>
            <span className="hidden md:inline text-gray-600">&bull;</span>
            <span>
              by <span className="text-gray-300 font-medium">Re-text</span>
            </span>
            <span className="hidden md:inline text-gray-600">&bull;</span>
            <span>
              Made in <span className="text-gray-300 font-medium">Gemini</span>
            </span>
          </div>
        </div>
      </footer>

      {/* Interactive Modal for Get Started / API 2.0 CTA */}
      {isModalOpen && (
        <div
          id="get-started-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in"
          onClick={() => setIsModalOpen(false)}
        >
          <div
            className="bg-[#1C1C1E] border border-white/10 rounded-2xl max-w-md w-full p-6 space-y-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <PletyLogo className="w-6 h-6 text-white" />
                <h3 className="text-lg font-bold text-white">Get Started with Plety</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-gray-300 leading-relaxed">
                {modalMessage}
              </p>

              <div className="bg-black/40 rounded-xl p-4 border border-white/5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Enterprise Ready Sandbox Activated</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-amber-400 font-medium">
                  <Zap className="w-4 h-4" />
                  <span>Sub-50ms API response guaranteed</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-blue-400 font-medium">
                  <Globe2 className="w-4 h-4" />
                  <span>95+ languages supported out of the box</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-400">Work Email</label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  defaultValue="developer@enterprise.com"
                  className="w-full bg-black/60 border border-white/10 rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-white/30"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-sm text-gray-400 hover:text-white font-medium"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setModalMessage("Access token generated! Your API sandbox environment is ready.");
                  setTimeout(() => {
                    setIsModalOpen(false);
                  }, 1200);
                }}
                className="px-5 py-2 text-sm bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-all cursor-pointer"
              >
                Launch Sandbox
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
